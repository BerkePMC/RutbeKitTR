<?php

/* Bu Eklenti Tamamen BerkePMC (Berke Yilmaz) Tarafindan Kodlanmistir. Satilmasi Yasaktir. Esya Idlerine Bakamayacagim Icin ByAlperenS (Alperen Sancak) 'in KitMenu Eklentisinden Idlere Bakilmistir.*/


namespace FightC;

use pocketmine\plugin\PluginBase;
use jojoe77777\FormAPI;
use pocketmine\{Player, Server};
use pocketmine\item\Item;
use pocketmine\command\{Command, CommandSender};
use pocketmine\block\Block;
use pocketmine\event\Listener;

class FightC extends PluginBase implements Listener{
	
	public function onEnable(){
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
		$this->getLogger()->info("Eklenti aktif.");
	
	}
	
	public function onCommand(CommandSender $o, Command $kmt, string $label, array $args): bool{
		if($kmt->getName() == "rutbekit"){
			$this->aForm($o);
		}
		return true;
	}
	
	public function aForm($o){
		$f = $this->getServer()->getPluginManager()->getPlugin("FormAPI")->createSimpleForm(function (Player $o, array $data){
		$re = $data[0];
		if($re === null){
			return true;
		}
		switch($re){
			case 0:
			$this->bForm($o);
			break;
		}
		switch($re){
			case 1:
			$this->cForm($o);
			break;
		}
		switch($re){
			case 2:
			$this->dForm($o);
			break;
		}
		switch($re){
			case 3:
			$this->eForm($o);
			break;
		}
		});
		$ad = $o->getName();
		$f->setTitle("Rutbe Kit Menu");
		$f->setContent("§7* Rutbe Kit Menu'ye Hos Geldin $ad!\nOldugun Rutbenin Kitlerini Al!");
		$f->addButton("§b* Comez Kit\n§7Tikla - Al");
		$f->addButton("§b* Asil Kit\n§7Tikla - Al");
		$f->addButton("§b* Kahraman Kit\n§7Tikla - Al");
		$f->addButton("§b* Padisah Kit\n§7Tikla - Al");
		$f->addButton("§b* Ayril");
		$f->sendToPlayer($o);
	}
	
	public function bForm($o){
	$f = $this->getServer()->getPluginManager()->getPlugin("FormAPI")->createSimpleForm(function (Player $o, array $data){
		$re = $data[0];
		if($re === null){
			return true;
		}
		switch($re){
			case 0:
			if($o->hasPermission("comez.rutbe")){
				$o->addTitle("§cComez Kiti Alindi!");
				$kilic = Item::get(272,0,1);
				$elma = Item::get(260,0,5);
				$kask = Item::get(298,0,1);
				$gomlek = Item::get(303,0,1);
				$pipilik = Item::get(300,0,1);
				$bot = Item::get(301,0,1);
				$kilic->setCustomName("§bComez Kilic");
				$elma->setCustomName("§eComez Elma");
				$o->getArmorInventory()->clearAll();
				$o->getArmorInventory()->setHelmet($kask);
				$o->getArmorInventory()->setChestplate($gomlek);
				$o->getArmorInventory()->setLeggings($pipilik);
				$o->getArmorInventory()->setBoots($bot);
				$o->getInventory()->addItem($kilic);
				$o->getInventory()->addItem($elma);
			} else{
				$o->sendPopUp("§cBu Kiti Almak Icin Rutben Yetmiyor.");
			}
			break;
		}
		});
		$isim = $o->getName();
		$f->setTitle("§7* Comez Kit");
		$f->setContent("§b* Comez Kit Alacak kisi : $ad\nIcindekiler : 1 Kilic, x5 Elma");
		$f->addButton("§aComez Kit Al", 0,"textures/blocks/diamond_block");
		$f->addButton("§cComez Kit Alma", 0,"textures/blocks/redstone_block");
		$f->sendToPlayer($o);
	}
	
	public function cForm($o){
	$f = $this->getServer()->getPluginManager()->getPlugin("FormAPI")->createSimpleForm(function (Player $o, array $data){
		$re = $data[0];
		if($re === null){
			return true;
		}
		switch($re){
			case 0:
			if($o->hasPermission("asil.rutbe")){
				$o->addTitle("§eAsil Kiti Alindi!");
				$kilic = Item::get(267,0,1);
				$elma = Item::get(260,0,10);
				$kask = Item::get(302,0,1);
				$gomlek = Item::get(303,0,1);
				$pipilik = Item::get(304,0,1);
				$bot = Item::get(305,0,1);
				$kilic->setCustomName("§bAsil Kilic");
				$goldenelma->setCustomName("§bAsil Altin Elma");
				$elma->setCustomName("§bAsil Elma");
				$o->getArmorInventory()->clearAll();
				$o->getArmorInventory()->addItem($kask);
				$o->getArmorInventory()->addItem($gomlek);
				$o->getArmorInventory()->addItem($pipilik);
				$o->getArmorInventory()->addItem($bot);
				$o->getInventory()->addItem($kilic);
				$o->getInventory()->addItem($elma);
			} else{
				$o->sendPopUp("§cBu Kiti Almak Icin Rutben Yetmiyor.");
			}
			break;
		}
		});
		$isim = $o->getName();
		$f->setTitle("§7* Asil Kit");
		$f->setContent("§bAsil Kit Alacak Kisi : $ad\nIcindekiler : 1 Kilic, x10 Elma");
		$f->addButton("§bAsil Kit Al", 0,"textures/blocks/diamond_block");
		$f->addButton("§cAsil Kit Alma", 0,"textures/blocks/redstone_block");
		$f->sendToPlayer($o);
	}
	
	public function dForm($o){
	$f = $this->getServer()->getPluginManager()->getPlugin("FormAPI")->createSimpleForm(function (Player $o, array $data){
		$re = $data[0];
		if($re === null){
			return true;
		}
		switch($re){
			case 0:
			if($o->hasPermission("kahraman.rutbe")){
				$o->sendPopUp("§bKahraman Kiti Alindi!");
				$kilic = Item::get(267,0,1);
				$goldenelma = Item::get(322,0,10);
				$elma = Item::get(260,0,15);
				$kask = Item::get(306,0,1);
				$gomlek = Item::get(307,0,1);
				$pipilik = Item::get(308,0,1);
				$bot = Item::get(309,0,1);
				$kilic->setCustomName("§bKahraman Kilic");
				$goldenelma->setCustomName("§bKahraman Altin Elma");
				$elma->setCustomName("§bKahraman Elma");
				$o->getArmorInventory()->clearAll();
				$o->getArmorInventory()->addItem($kask);
				$o->getArmorInventory()->addItem($gomlek);
				$o->getArmorInventory()->addItem($pipilik);
				$o->getArmorInventory()->addItem($bot);
				$o->getInventory()->addItem($kilic);
				$o->getInventory()->addItem($goldenelma);
				$o->getInventory()->addItem($elma);
			} else{
				$o->sendPopUp("§cBu Kiti Almak Icin Rutben Yetmiyor!");
			}
			break;
		}
		});
		$isim = $o->getName();
		$f->setTitle("§7* Kahraman Kit");
		$f->setContent("§bKahraman Kit Alacak Kisi : $ad\nIcindekiler : 1 Kilic, x10 Altin Elma, x15 Elma");
		$f->addButton("§bKahraman Kit Al", 0,"textures/blocks/diamond_block");
		$f->addButton("§bKahraman Kit Alma", 0,"textures/blocks/redstone_block");
		$f->sendToPlayer($o);
	}
	
	public function eForm($o){
	$f = $this->getServer()->getPluginManager()->getPlugin("FormAPI")->createSimpleForm(function (Player $o, array $data){
		$re = $data[0];
		if($re === null){
			return true;
		}
		switch($re){
			case 0:
			if($o->hasPermission("padisah.rutbe")){
				$o->sendMessage("§bPadisah Kiti Alindi!");
				$kilic = Item::get(276,0,1);
				$goldenelma = Item::get(322,0,15);
				$elma = Item::get(260,0,20);
				$silah = Item::get(261,0,1);
				$sarjor = Item::get(262,0,16);
				$kask = Item::get(306,0,1);
				$gomlek = Item::get(307,0,1);
				$pipilik = Item::get(312,0,1);
				$bot = Item::get(313,0,1);
				$kilic->setCustomName("§bPadisah Kilic");
				$goldenelma->setCustomName("§bPadisah Altin Elma");
				$elma->setCustomName("§bPadisah Elma");
				$silah->setCustomName("§bPadisah Silah");
				$sarjor->setCustomName("§bPadisah Sarjor");
				$o->getArmorInventory()->clearAll();
				$o->getArmorInventory()->addItem($kask);
				$o->getArmorInventory()->addItem($gomlek);
				$o->getArmorInventory()->addItem($pipilik);
				$o->getArmorInventory()->addItem($bot);
				$o->getInventory()->addItem($kilic);
				$o->getInventory()->addItem($goldenelma);
				$o->getInventory()->addItem($elma);
				$o->getInventory()->addItem($silah);
				$o->getInventory()->addItem($sarjor);
			} else{
				$o->sendPopUp("§cBu Kiti Alabilmek Icin Rutben Yetmiyor.");
			}
			break;
		}
		});
		$isim = $o->getName();
		$f->setTitle("§7* Padisah Kit");
		$f->setContent("§bPadisah Kit Alacak Kisi : $ad\nIcindekiler : 1 Kilic, x15 Altin Elma, x20 Elma, x1 Silah, x16 Sarjor");
		$f->addButton("§bPadisah Kit Al", 0,"textures/blocks/diamond_block");
		$f->addButton("§bPadisah Kit Alma", 0,"textures/blocks/redstone_block");
		$f->sendToPlayer($o);
	}
}
?>